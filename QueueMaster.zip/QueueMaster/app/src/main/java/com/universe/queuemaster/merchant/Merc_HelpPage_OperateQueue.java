package com.universe.queuemaster.merchant;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.universe.queuemaster.R;

public class Merc_HelpPage_OperateQueue extends AppCompatActivity {
    private static final String TAG = "Helppage_merc_createQueue";

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.merc_help_page_operate);
    }

}
